#ifndef MYAI_H
#define MYAI_H

#define _USE_MATH_DEFINES

#include "botai.h"

class MyAI : public BotAI
{
    bool fireAfterMove;
    bool dumb;
public:
    MyAI(bool dumb);
    ~MyAI() override;
    virtual BotCmd handleEvents(BotEvent& event) override;
    void setKilled() override;
};

class BoiAI : public BotAI
{
    bool targeted = false;
public:
    BoiAI();
    ~BoiAI() override;
    virtual BotCmd handleEvents(BotEvent& event) override;
    void setKilled() override;
};

#endif // MYAI_H
