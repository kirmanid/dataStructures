#define _USE_MATH_DEFINES
#include "vec2d.h"
#include "myai.h"
#include "random.h"

Random aiRand;

using namespace std;

MyAI::MyAI(bool dumb)
    : dumb(dumb)
{
    setName("Boop");
    fireAfterMove = false;
}

MyAI::~MyAI()
{
}

void MyAI::setKilled()
{
}

BotCmd MyAI::handleEvents(BotEvent& event)
{
    if (dumb) {
        return Ignore();
    }

    switch (event.eventType)
    {
    case BotEventType::TurnComplete:
        //cout << "MyAI: TurnComplete" << endl;
        if (fireAfterMove) {
            fireAfterMove = false;
            return Move(-50,3);
        }
        else {
            return Move(50,3);
        }
        break;
    case BotEventType::ScanComplete:
        return Fire();
    case BotEventType::FireComplete:
        return Move(50,0.4);
    case BotEventType::NoBullets:
        return Turn(0.7);
    case BotEventType::MoveComplete:
        if (fireAfterMove && event.bulletCount > 0) {
            //fireAfterMove = false;
            return Fire();
        }
        else {
            return Turn(aiRand.randomTrue(0.5) ? aiRand.randomDouble(.2,1) : aiRand.randomDouble(-1,-.2));
        }
        break;
    case BotEventType::MoveBlockedByWall:
        if (event.collisionAngle < 0) {
            return Turn(M_PI/2+event.collisionAngle+aiRand.randomDouble(0.01,.2));
        }
        else {
            return Turn(-M_PI/2+event.collisionAngle-aiRand.randomDouble(0.01,.2));
        }
        break;
    case BotEventType::MoveBlockedByBot:
    case BotEventType::HitByBot:
        if (event.collisionAngle < 0.75 && event.collisionAngle > -0.75) {
            //cout << "Back up and fire!" << endl;
            fireAfterMove = true;
            return Move(-50,0.2);
        }
        else if (event.collisionAngle < 0) {
            return Turn(M_PI/2+event.collisionAngle+aiRand.randomDouble(-.5,.5));
        }
        else {
            return Turn(-M_PI/2+event.collisionAngle+aiRand.randomDouble(-.5,.5));
        }
        break;
    case BotEventType::HitByBullet:
        //fireAfterMove = true;
        return Move(-50,1);
    case BotEventType::PowerUp:
        //std::cout << "MyAI: Got a power up!!!" << std::endl;
        return Ignore();
    }

    return Move(50,1); // shouldn't get here
}

BoiAI::BoiAI()
{
    setName("Egg");
}

BoiAI::~BoiAI()
{

}


void BoiAI::setKilled()
{
   // cout << "ThisGuyKilled" << endl;
}

BotCmd BoiAI::handleEvents(BotEvent& event)
{
    switch (event.eventType)
    {
    case BotEventType::FireComplete:
        if(!targeted)
        {
            return Move(-50, 0.25);
        }
        targeted = false;
        return Scan(0.5);

    case BotEventType::NoBullets:

        return Turn(0.5);
    case BotEventType::MoveBlockedByWall:
        return Move(-50, 1);
    case BotEventType::MoveComplete:
        return Scan(0.5);
    case BotEventType::MoveBlockedByBot:
        return Fire();
    case BotEventType::TurnComplete:
        if(targeted == true)
        {
            return Fire();
        }
        return Move(50, 1);
    case BotEventType::ScanComplete:
        for(int i = 0; i < event.scanData.size(); i ++)
        {
            if(event.scanData[i])
            {
                i -= (event.scanData.size()/2);
                targeted = true;
                return (Turn(-(((0.5)/500) * i)));
            }
        }
        if(event.scanData[250])
        {
            return Fire();
        }
        else
        {
            return Turn(1);
        }
    case BotEventType::HitByBot:
        return Fire();
    case BotEventType::HitByBullet:
        return Move(-50, 0.5);
    case BotEventType::PowerUp:
        return Ignore();
    }
}


