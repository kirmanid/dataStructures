#include "plugin.h"

using namespace mssm;

Plugin::Plugin(QObject *parent) : QObject(parent)
{

}

Plugin::~Plugin()
{

}
