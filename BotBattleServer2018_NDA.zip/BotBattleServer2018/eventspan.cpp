#include "eventspan.h"
/*
EventSpan::EventSpan()
{

}
*/
